# README

We are identifying food entities the Yelp reviews dataset. 

> Food entity is defined as any noun that can occur in a food menu excluding generic terms like food, water, lunch etc.

Each food entity is annotated in its entirety using xml tags `< />`

> I ordered \<pizza/> and \<kale juice/>
